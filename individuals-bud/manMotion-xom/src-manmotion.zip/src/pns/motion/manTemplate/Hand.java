package pns.motion.manTemplate;

import pns.motion.limbTemplate.Limb;

public class Hand extends Limb {

	public Hand(boolean isRight) {
		super(isRight);
		// TODO Auto-generated constructor stub
	}

}
