package pns.motion.manTemplate;

import pns.motion.limbTemplate.Limb;

public class Body extends Limb {

	public Body(boolean isRight) {
		super(isRight);
		// TODO Auto-generated constructor stub
	}

}
