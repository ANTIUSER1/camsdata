package pns.motion.manTemplate;

import pns.motion.coordinatesData.Position3d;
import pns.motion.limbTemplate.LimbElement;

public class Head extends LimbElement {

	public Head() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Head(Position3d space, Position3d velocity, Position3d acceleration,
			Position3d magnet) {
		super(space, velocity, acceleration, magnet);
		// TODO Auto-generated constructor stub
	}

}
