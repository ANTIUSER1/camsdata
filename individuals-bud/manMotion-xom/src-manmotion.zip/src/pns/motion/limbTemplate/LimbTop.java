package pns.motion.limbTemplate;

import pns.motion.coordinatesData.Position3d;

public class LimbTop extends LimbElement {
	public LimbTop() {
		super();
	}

	public LimbTop(Position3d space, Position3d velocity,
			Position3d acceleration, Position3d magnet) {
		super(space, velocity, acceleration, magnet);
		// TODO Auto-generated constructor stub
	}

}
