package pns.motion.limbTemplate;

import pns.motion.coordinatesData.Position3d;

public class LimbBottom extends LimbElement {

	public LimbBottom() {
		super();
	}

	public LimbBottom(Position3d space, Position3d velocity,
			Position3d acceleration, Position3d magnet) {
		super(space, velocity, acceleration, magnet);
		// TODO Auto-generated constructor stub
	}

}
